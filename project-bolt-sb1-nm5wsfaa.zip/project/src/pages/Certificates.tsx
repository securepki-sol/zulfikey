import React from 'react';
import CertificateSearch from '../components/Certificates/CertificateSearch';
import QuickActions from '../components/Certificates/QuickActions';

export default function CertificatesPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Certificate Management</h1>
        <p className="text-gray-600">Search, manage, and monitor your certificates</p>
      </div>
      
      <CertificateSearch />
      <QuickActions />
    </div>
  );
}