import React from 'react';
import { FileKey, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import type { Certificate } from '../types';

const mockCertificates: Certificate[] = [
  {
    id: '1',
    commonName: '*.example.com',
    organization: 'Example Corp',
    validFrom: new Date('2024-01-01'),
    validTo: new Date('2025-01-01'),
    status: 'active',
    issuer: 'DigiCert Global Root CA',
    serialNumber: '123456789',
    keyType: 'RSA',
    keySize: 2048
  },
  // Add more mock certificates as needed
];

const statusColors = {
  active: 'text-green-600',
  expired: 'text-red-600',
  revoked: 'text-gray-600'
};

const StatusIcon = ({ status }: { status: Certificate['status'] }) => {
  const icons = {
    active: CheckCircle,
    expired: AlertTriangle,
    revoked: XCircle
  };
  const Icon = icons[status];
  return <Icon className={`w-5 h-5 ${statusColors[status]}`} />;
};

export default function CertificateList() {
  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-800">Certificates</h2>
          <button className="bg-emerald-500 text-white px-4 py-2 rounded-lg hover:bg-emerald-600 transition-colors flex items-center space-x-2">
            <FileKey className="w-4 h-4" />
            <span>New Certificate</span>
          </button>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Common Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Organization</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Valid Until</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Issuer</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {mockCertificates.map((cert) => (
              <tr key={cert.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <StatusIcon status={cert.status} />
                </td>
                <td className="px-6 py-4 whitespace-nowrap">{cert.commonName}</td>
                <td className="px-6 py-4 whitespace-nowrap">{cert.organization}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {cert.validTo.toLocaleDateString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">{cert.issuer}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}