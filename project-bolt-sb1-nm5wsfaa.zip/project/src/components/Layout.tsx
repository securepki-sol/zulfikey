import React from 'react';
import { Shield, Settings, HelpCircle, LogOut } from 'lucide-react';
import Tabs from './Navigation/Tabs';

const APP_VERSION = 'v10.4.1.1';
const MOCK_USER = {
  name: 'John Doe',
  email: 'john.doe@example.com'
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-gray-900 text-white">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            {/* Logo and Version */}
            <div className="flex items-center space-x-3">
              <Shield className="w-8 h-8 text-emerald-500" />
              <div className="flex items-baseline space-x-2">
                <h1 className="text-xl font-bold">ZulfiKey</h1>
                <span className="text-sm text-gray-400">{APP_VERSION}</span>
              </div>
            </div>

            {/* User Controls */}
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-300">{MOCK_USER.name}</span>
              <button 
                className="p-2 text-gray-400 hover:text-white transition-colors"
                title="Settings"
              >
                <Settings className="w-5 h-5" />
              </button>
              <button 
                className="p-2 text-gray-400 hover:text-white transition-colors"
                title="Help"
              >
                <HelpCircle className="w-5 h-5" />
              </button>
              <button 
                className="p-2 text-gray-400 hover:text-white transition-colors"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <Tabs />

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        {children}
      </main>
    </div>
  );
}