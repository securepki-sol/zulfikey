import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  FileKey, 
  BarChart3, 
  FilePlus, 
  Bell, 
  GitBranch, 
  MapPin, 
  Settings,
} from 'lucide-react';
import { 
  certificateMenu, 
  reportsMenu, 
  enrollmentMenu, 
  alertsMenu, 
  workflowMenu, 
  locationMenu, 
  orchestratorsMenu 
} from './dropdownMenus';
import type { Tab } from './types';

const tabs: Tab[] = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
  { 
    icon: FileKey, 
    label: 'Certificates', 
    path: '/certificates',
    hasDropdown: true,
    menu: certificateMenu
  },
  { 
    icon: BarChart3, 
    label: 'Reports', 
    path: '/reports',
    hasDropdown: true,
    menu: reportsMenu
  },
  { 
    icon: FilePlus, 
    label: 'Enrollment', 
    path: '/enrollment',
    hasDropdown: true,
    menu: enrollmentMenu
  },
  { 
    icon: Bell, 
    label: 'Alerts', 
    path: '/alerts',
    hasDropdown: true,
    menu: alertsMenu
  },
  { 
    icon: GitBranch, 
    label: 'Workflow', 
    path: '/workflow',
    hasDropdown: true,
    menu: workflowMenu
  },
  { 
    icon: MapPin, 
    label: 'Location', 
    path: '/location',
    hasDropdown: true,
    menu: locationMenu
  },
  { 
    icon: Settings, 
    label: 'Orchestrators', 
    path: '/orchestrators',
    hasDropdown: true,
    menu: orchestratorsMenu
  },
];

export default function Tabs() {
  const [activeTab, setActiveTab] = useState('/');
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  const handleTabHover = (tab: Tab) => {
    if (tab.hasDropdown) {
      setActiveDropdown(tab.path);
    }
  };

  const handleMouseLeave = () => {
    setActiveDropdown(null);
  };

  const handleTabClick = (tab: Tab) => {
    setActiveTab(tab.path);
    if (!tab.hasDropdown) {
      setActiveDropdown(null);
    }
  };

  return (
    <div className="bg-white border-b relative">
      <nav className="px-4">
        <div className="flex space-x-1">
          {tabs.map((tab) => (
            <div 
              key={tab.path} 
              className="relative"
              onMouseEnter={() => handleTabHover(tab)}
              onMouseLeave={handleMouseLeave}
            >
              <button
                onClick={() => handleTabClick(tab)}
                className={`
                  flex items-center space-x-2 px-4 py-3 text-sm font-medium border-b-2 
                  hover:text-emerald-600 hover:border-emerald-600 transition-colors
                  ${activeTab === tab.path 
                    ? 'border-emerald-500 text-emerald-600' 
                    : 'border-transparent text-gray-500'}
                `}
              >
                <tab.icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>

              {/* Dropdown Menu */}
              {tab.hasDropdown && activeDropdown === tab.path && tab.menu && (
                <div 
                  className="absolute left-0 mt-1 w-64 bg-white border rounded-lg shadow-lg py-2 z-50"
                >
                  {tab.menu.items.map((item) => (
                    <button
                      key={item.path}
                      onClick={() => {
                        setActiveTab(item.path);
                        setActiveDropdown(null);
                      }}
                      className="w-full flex items-center space-x-2 px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600"
                    >
                      <item.icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </nav>
    </div>
  );
}