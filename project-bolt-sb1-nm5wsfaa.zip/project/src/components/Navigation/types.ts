import { LucideIcon } from 'lucide-react';

export interface MenuItem {
  icon: LucideIcon;
  label: string;
  path: string;
}

export interface MenuConfig {
  items: MenuItem[];
}

export interface Tab {
  icon: LucideIcon;
  label: string;
  path: string;
  hasDropdown?: boolean;
  menu?: MenuConfig;
}