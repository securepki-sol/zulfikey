import { 
  Search, Plus, FolderPlus, Clock, ShieldAlert, Award, User,
  FileText, FolderSearch, Calendar, ClipboardList, Database, PieChart, BarChart,
  XCircle, FileSignature, FileQuestion, FileCheck, Loader, AlertTriangle,
  XOctagon, CheckCircle, GitBranch2, List, UserCircle, Building,
  KeyRound, FileKey, HardDrive, Scan, RotateCw, Settings, 
  PlayCircle, FileCode, Apple
} from 'lucide-react';
import type { MenuConfig } from './types';

export const certificateMenu: MenuConfig = {
  items: [
    { icon: Search, label: 'Certificate Search', path: '/certificates/search' },
    { icon: Plus, label: 'Add Certificate', path: '/certificates/add' },
    { icon: FolderPlus, label: 'Collection Manager', path: '/certificates/collections' },
    { icon: Clock, label: 'Certificates Expiring in 7 Days', path: '/certificates/expiring' },
    { icon: ShieldAlert, label: 'Certificates with Weak Encryption', path: '/certificates/weak' },
    { icon: Award, label: 'Digicert-Certificates', path: '/certificates/digicert' },
    { icon: User, label: 'My Certificates', path: '/certificates/my' },
    { icon: XCircle, label: 'Revoked Certificates', path: '/certificates/revoked' },
    { icon: FileSignature, label: 'Self-Signed Certificates', path: '/certificates/self-signed' }
  ]
};

export const reportsMenu: MenuConfig = {
  items: [
    { icon: FileText, label: 'Report Manager', path: '/reports/manager' },
    { icon: FolderSearch, label: 'Certificates in Collection', path: '/reports/collection-certs' },
    { icon: Calendar, label: 'Expiration Report', path: '/reports/expiration' },
    { icon: Clock, label: 'Expiration Report by Days', path: '/reports/expiration-days' },
    { icon: Database, label: 'Full Certificate Extract', path: '/reports/full-extract' },
    { icon: ShieldAlert, label: 'PKI Status for Collection', path: '/reports/pki-status' },
    { icon: PieChart, label: 'Statistical Report', path: '/reports/statistics' }
  ]
};

export const enrollmentMenu: MenuConfig = {
  items: [
    { icon: FileQuestion, label: 'CSR Enrollment', path: '/enrollment/csr' },
    { icon: FileCheck, label: 'CSR Generation', path: '/enrollment/csr-generation' },
    { icon: Loader, label: 'Pending CSRs', path: '/enrollment/pending' },
    { icon: FileKey, label: 'PFX Enrollment', path: '/enrollment/pfx' },
    { icon: AlertTriangle, label: 'Certificate Requests', path: '/enrollment/requests' }
  ]
};

export const alertsMenu: MenuConfig = {
  items: [
    { icon: Clock, label: 'Expiration', path: '/alerts/expiration' },
    { icon: Loader, label: 'Pending Request', path: '/alerts/pending' },
    { icon: CheckCircle, label: 'Issued Request', path: '/alerts/issued' },
    { icon: XOctagon, label: 'Denied Request', path: '/alerts/denied' },
    { icon: AlertTriangle, label: 'Revocation Monitoring', path: '/alerts/revocation' }
  ]
};

export const workflowMenu: MenuConfig = {
  items: [
    { icon: List, label: 'Definitions', path: '/workflow/definitions' },
    { icon: PlayCircle, label: 'Instances', path: '/workflow/instances' },
    { icon: UserCircle, label: 'My Workflows', path: '/workflow/my' }
  ]
};

export const locationMenu: MenuConfig = {
  items: [
    { icon: Building, label: 'Certificate Authorities', path: '/location/authorities' },
    { icon: KeyRound, label: 'Certificate Templates', path: '/location/templates' },
    { icon: HardDrive, label: 'Certificate Stores', path: '/location/stores' },
    { icon: Scan, label: 'SSL Discovery', path: '/location/discovery' }
  ]
};

export const orchestratorsMenu: MenuConfig = {
  items: [
    { icon: RotateCw, label: 'Auto-Registration', path: '/orchestrators/auto-registration' },
    { icon: Settings, label: 'Management', path: '/orchestrators/management' },
    { icon: PlayCircle, label: 'Jobs', path: '/orchestrators/jobs' },
    { icon: FileCode, label: 'Blueprints', path: '/orchestrators/blueprints' },
    { icon: Apple, label: 'Mac Auto-Enrollment', path: '/orchestrators/mac-enrollment' }
  ]
};