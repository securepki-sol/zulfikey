import React from 'react';
import { Plus, FolderPlus, Clock, ShieldAlert, Award, User } from 'lucide-react';

const actions = [
  { icon: Plus, label: 'Add Certificate', path: '/certificates/add' },
  { icon: FolderPlus, label: 'Collection Manager', path: '/certificates/collections' },
  { icon: Clock, label: 'Expiring in 7 Days', count: 12, variant: 'warning' },
  { icon: ShieldAlert, label: 'Weak Encryption', count: 3, variant: 'danger' },
  { icon: Award, label: 'Digicert-Certificates', count: 45, variant: 'info' },
  { icon: User, label: 'My Certificates', count: 8, variant: 'success' },
];

const variantStyles = {
  warning: 'bg-amber-50 text-amber-700 border-amber-200',
  danger: 'bg-red-50 text-red-700 border-red-200',
  info: 'bg-blue-50 text-blue-700 border-blue-200',
  success: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  default: 'bg-white hover:bg-gray-50',
};

export default function QuickActions() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {actions.map((action) => (
        <button
          key={action.label}
          className={`
            p-4 rounded-lg border shadow-sm
            ${action.variant ? variantStyles[action.variant] : variantStyles.default}
            transition-all duration-200 hover:shadow-md
          `}
        >
          <div className="flex items-center space-x-3">
            <action.icon className="w-5 h-5" />
            <span className="font-medium">{action.label}</span>
            {action.count !== undefined && (
              <span className="ml-auto bg-white px-2 py-1 rounded-full text-sm font-medium shadow-sm">
                {action.count}
              </span>
            )}
          </div>
        </button>
      ))}
    </div>
  );
}