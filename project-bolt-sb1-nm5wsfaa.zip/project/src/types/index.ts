export interface Certificate {
  id: string;
  commonName: string;
  organization: string;
  validFrom: Date;
  validTo: Date;
  status: 'active' | 'expired' | 'revoked';
  issuer: string;
  serialNumber: string;
  keyType: string;
  keySize: number;
}

export interface CertificateStore {
  id: string;
  name: string;
  type: 'jks' | 'pkcs12' | 'pem';
  location: string;
  certificates: string[]; // Certificate IDs
  lastSync: Date;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'operator' | 'auditor';
  lastLogin: Date;
}