import React from 'react';
import Layout from './components/Layout';
import CertificatesPage from './pages/Certificates';

function App() {
  return (
    <Layout>
      <CertificatesPage />
    </Layout>
  );
}

export default App;